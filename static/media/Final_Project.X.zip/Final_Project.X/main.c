#include "mcc_generated_files/system/system.h"

#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#define BUFSIZE 16
#define MSGSIZE 64
#define TEAMSIZE 5
#define TYPESIZE 4
#define MSGTESTSIZE 64
#define MSGTESTCHAR 0

const char id = 'A';
const char team_id[TEAMSIZE + 1] = "MASHX";
const uint8_t message_types[TYPESIZE] = {0x00, 0x01,0x02,0x03};
const uint8_t status[TYPESIZE] = {0x00,0x01,0x02,0x03};
const uint8_t drive[TYPESIZE] = {0x00,0x01};
const uint8_t sens[TYPESIZE] = {0x00,0x01,0x02,0x03};
const uint8_t dir[TYPESIZE] = {0x00,0x01,0x02,0x03};
char buffer_in[BUFSIZE + 1];
char message_in[MSGSIZE + 1];
char message_out[MSGSIZE+1];
int init = 0;
int initSent = 0;



float timeCurrent = 0.0;
float timeLast = 0.0;
float timeHeldStart = 0.0;
int secHeld = 0;
volatile uint32_t time_ms = 0;
int time_s = 0;
int i = 0;
int counter = 1;
int update = 0;
int lastp = 0;
int sent = 0;

int drivemode = 0;
volatile uint32_t timeStamp = 0;

int positionSetvar = 0;
float currentTime = 0;

volatile uint32_t LED_1_lastToggle = 0;
volatile uint32_t LED_2_lastToggle = 0;
volatile uint16_t LED_1_interval  = 0;    // in ms
volatile uint16_t LED_2_interval  = 0;    // in ms
uint8_t  LED_1_enabled   = 0;


int SWCurrent;
int SWLast;
int lastSecondBlink;
float debounceDelay = 0.050;


void fill_string(char * mystring, char value, unsigned int size){
    for(int ii=0;ii<size;ii++){
        mystring[ii]=value;
    }
}


unsigned int find_char(const char * mystring, char value, unsigned int size){
    char c = 0;
    for(int ii = 0; ii<size; ii++){
        c = mystring[ii];
        //printf("%c,%c; ",value, mystring[ii]);
        if(c==value){
            return 1;
        }
    }
    return 0;
}

void handle_message(char sender, char receiver, char type, char subtype){
    //message_in[ii-2]=0;
    printf("AZ%c%c%c%cYB",sender,receiver,type,subtype);
}

//void test_message(char type, char val){
//    if(message_in[4] == type && message_in[5] == val){
//        for(i = 0; i < type; i++){
//            LED_1_SetHigh();
//            __delay_ms(200);
//            LED_1_SetLow();
//            __delay_ms(200);
//        }
//        for(i = 0; i < val; i++){
//            LED_2_SetHigh();
//            __delay_ms(200);
//            LED_2_SetLow();
//            __delay_ms(200);
//        }
//    }
//}
void ACTUATOR_init(){
    printf("AZAH%c%cYB",0x00,0x00);
}

void uart_callback(void){
    //ms++;
}

// Nonblocking code to keep track of time
void timer_callback(){
    time_ms = time_ms+1;
}

void StatusLight(void) {
    if(LED_1_enabled==1){
    if ((time_ms - LED_1_lastToggle) >= LED_1_interval) {
        LED_1_Toggle();
        LED_1_lastToggle = time_ms;
    }
    }
}

void positionSet(int position){
    int p = position;
    
    if(update==1){
        LED_2_lastToggle = time_ms;
        update = 0;
    }
    currentTime = time_s;
     
    if(p == 1){
        LED_2_interval = 500;
        if ((time_ms - LED_2_lastToggle) >= LED_2_interval) {
        LED_2_Toggle();
        LED_2_lastToggle = time_ms;
        }
    }
    if(p == 2){
        LED_2_interval = 250;
        if ((time_ms - LED_2_lastToggle) >= LED_2_interval) {
        LED_2_Toggle();
        LED_2_lastToggle = time_ms;
        }
    }
    if(p == 3){
        LED_2_interval = 166;
        if ((time_ms - LED_2_lastToggle) >= LED_2_interval) {
        LED_2_Toggle();
        LED_2_lastToggle = time_ms;
        }
    }
    if(p == 0){
            LED_2_SetLow();
            //currentTime=0;
    }
    
//    if(currentTime-timeStamp>=4000){
//        lastp = p;
//        p==0;
//    }
}

void sendToEric(int pos){
        if(pos == 0 && (time_ms-timeStamp >5000) && sent == 0){
            printf("AZAS%c%cYB",0x03,0x00);
            sent =1;
        }
        if(pos == 1 && (time_ms-timeStamp >5000) && sent == 0){
            printf("AZAS%c%cYB",0x03,0x01);
            sent =1;
        }
        if(pos == 2 && (time_ms-timeStamp >5000) && sent == 0){
            printf("AZAS%c%cYB",0x03,0x02);
            sent =1;
        }
//        if((time_ms-timeStamp > 10000)){
//            printf("AZAS%c%cYB",0x03,0x00);
//        }
    }

void pin_down(){  
}

void SPI1_Send(uint8_t command)
{
    CSN1_SetLow();
    __delay_ms(20);
    SPI1_ByteExchange(command);
    __delay_ms(20);
    CSN1_SetHigh();
}
void SPI2_Send(uint8_t command)
{
    CSN2_SetLow();
    __delay_ms(20);
    SPI1_ByteExchange(command);
    __delay_ms(20);
    CSN2_SetHigh();
}




int main(void)
{
    SYSTEM_Initialize();
 
    
    INTERRUPT_GlobalInterruptEnable();    
    
    UART1_Initialize();
    UART1_Enable();
    
    CSN1_SetLow();
    CSN2_SetLow();
    
    SPI1_Initialize();

    SPI1_Open(HOST_CONFIG);

    
    LED_1_SetHigh();
    
//    printf("AZAH%c%cYB",0x02,0x01);

    
    
    char c=0;
    char sender;
    char receiver;
    char type;
    char subtype;
    unsigned int pass = 0;
    unsigned int buffer_ii = 0;
    unsigned int buffer_last_ii = 0;
    unsigned int message_ii = 0;
    unsigned int message_last_ii = 0;
    buffer_in[BUFSIZE] = 0;
    message_in[MSGSIZE] = 0;
    unsigned int message_incoming = 0;
    fill_string(buffer_in, 'a', BUFSIZE);
    fill_string(message_in,'_',MSGSIZE);
    message_in[MSGTESTSIZE] = MSGTESTCHAR;
    
    uint8_t Fwd;
    uint8_t Rev;
    uint8_t Off;
    Fwd = 0b11101111;//btyes swapped
    Rev = 0b11101101;
    Off = 0b11101000;
    
    CSN1_SetHigh();
    CSN2_SetHigh();
    SPI1_Send(Off);
    SPI2_Send(Off);
    
    printf("AZSH0x020x00YB");
    UART1_RxCompleteCallbackRegister(uart_callback);
    //BTN_SetInterruptHandler(pin_down);
    TMR0_PeriodMatchCallbackRegister(timer_callback);
    TMR0_Start();
    while(1){
        
        StatusLight();
        positionSet(positionSetvar);
        
        
        
        
        if(drivemode == 1){
            sendToEric((positionSetvar-1));
        }
        
        
        if(BTN_GetValue()==0){
            //printf("AZAH%c%cYB",0x02,0x00);

//            SPI_Send(0b10000000);
            //CSN1_SetLow();
            __delay_ms(100);
            SPI1_Send(Rev);
            SPI2_Send(Rev);
            
        }
        
        
        if(UART1_IsRxReady())
            {

                c = UART1_Read();
                buffer_in[buffer_ii]=c;
                
                // If AZ is detected - start recording
                if (buffer_in[buffer_last_ii]=='A' & buffer_in[buffer_ii]=='Z'){
                    //printf("Message start:  ");
                    fill_string(message_in,'_',MSGSIZE);
                    message_in[MSGTESTSIZE]=MSGTESTCHAR;
                    message_incoming=1;
                    message_in[0] = buffer_in[buffer_last_ii]; // Set A to position 0 in message array
                    message_ii=1;
                    pass = 0;
                }
                
                // If YB is detected - end recording
                if (buffer_in[buffer_last_ii]=='Y' & buffer_in[buffer_ii]=='B'){
                    //printf(" Message end ");
                    message_incoming=0;
                    message_in[message_ii] = buffer_in[buffer_ii];
                    message_in[message_ii + 1] = '\0'; 
                    message_last_ii= message_ii;
                    message_ii = message_ii+1;
                    if(pass == 0){
                        //printf("Message for me: %c,%c,%c,%c",sender,receiver,type,subtype);
                    }
                    else{
                        handle_message(sender,receiver,type,subtype);
                        continue;
                    }
                    if(initSent==0){
                        if(init == 1){
                            ACTUATOR_init();
                            initSent = 1;
                        }
                    }
                    
                    //printf("%s",message_in);
//                    test_message(type,subtype);
                    
                }
                if (message_incoming != 0){
                    message_in[message_ii] = buffer_in[buffer_ii];
                    
                    
                    // Determine sender - 3rd position in array
                    if (message_ii==2){
                        unsigned result = 0;
                        char d=0;

                        d = message_in[message_ii];
                        result= find_char(team_id,d,TEAMSIZE);
                        if (result==0){
                            //printf(" Error: sender not in team - terminating");
                            break;
                        } else {
                            //printf(" Sender: %c |", d);
                            sender = d;
                        }
                        if (sender == "X" || sender == "A"){
                            pass = 0;
                        }
                    }
                    
                    // Determine receiver - 4th position in array
                    if (message_ii==3){
                        unsigned result = 0;
                        char d=0;

                        d = message_in[message_ii];
                        result= find_char(team_id,d,TEAMSIZE);
                        if (result==0){
                            //printf(" Error: receiver not in team - terminating");
                            break;
                        } else {
                            switch(d){
                                case 'A':
                                    //printf(" Message is for me |");
                                    pass = 0;
                                    break;
                                case 'X':
                                    //printf(" Message is for everyone |");
                                    pass = 1;
                                    break;
                                default:
                                    //printf(" Message is not for me |");
                                    pass = 1;
                                    break;
                            }
                            receiver = d;
                        }
                    }
                    
                    // Determine message type - 5th position in array
                    if (message_ii==4){
                        unsigned result = 0;
                        char d=0;
                        
                        d = message_in[message_ii];
                        result= find_char(message_types,d,TYPESIZE);
                        if (result==0){
                            //printf(" Error: message type invalid - terminating");
                            break;
                        } else {
                            switch(d){ // print message type
                                case 0x00:
                                    //printf(" Status code: ");
                                    break;
                                case 0x01:
                                    //printf(" Drive mode: ");
                                    break;
                                case 0x02:
                                    //printf(" Sensor data: ");
                                    break;
                                case 0x03:
                                    //printf(" Path selection: ");
                                    break;
                            }
                            type = d;
                        }
                    }
                    
                    // Determine message data - 6th position in array
                    if (message_ii==5){
                        unsigned result = 0;
                        char d=0;
                        
                        d = message_in[message_ii];
                        result= find_char(message_types,d,TYPESIZE);
                        if (result==0){
                            //printf(" Error: message type invalid - terminating");
                            break;
                        } else {
                            switch(type){
                                case 0x00:
                                    switch(d){
                                        case 0x00:
                                            //printf("%c initialized", sender);
                                            init = 1;
                                            LED_1_interval = 500;
                                            LED_1_enabled = 1;
                                            printf("AZAH%c%cYB",0x00,0x00);
                                            printf("AZAH%c%cYB",0x02,0x00);
                                            break;
                                        default:
                                            //printf("Error: invalid status code - terminating");
                                            break;
                                    }
                                    break;
                                case 0x01:
                                    switch(d){
                                        case 0x00:
                                            printf(" Automatic ");
                                            LED_1_interval = 250;
                                            drivemode = 1;
                                            printf("AZAS%c%cYB",0x03,0x00);
                                            break;
                                        case 0x01:
                                            printf(" Direct drive ");
                                            LED_1_interval = 1000;
                                            drivemode = 2;
                                            break;
                                        default:
                                            printf("Error: Invalid drive code - terminating");
                                            break;
                                    }
                                    break;
                                case 0x02:
                                    switch(d){
                                        case 0x00:
                                            //printf("ORANGE ");
                                            if(drivemode==1){
                                                update = 1;
                                                positionSetvar=1;
                                                timeStamp= time_ms;
                                            }
                                            
                                            break;
                                        case 0x01:
                                            //printf("BLUE ");
                                            if(drivemode==1){
                                                update = 1;
                                                positionSetvar=2;
                                                timeStamp=time_ms;
                                            }
                                            break;
                                        case 0x02:
                                            //printf("PINK ");
                                            if(drivemode==1){
                                                update = 1;
                                                positionSetvar=3;
                                                timeStamp=time_ms;
                                            }
                                            break;
                                        default:
                                            printf("Error: Invalid color code - terminating");
                                            break;
                                    }
                                    break;
                                case 0x03:
                                    printf("3");
                                    switch(d){
                                        case 0x00:
                                            //printf("LEFT ");

                                             update = 1;
                                             positionSetvar=1;
                                             SPI1_Send(Fwd);
                                             timeStamp= time_ms;
                                            break;
                                        case 0x01:
                                            //printf("CENTER ");

                                                update = 1;
                                                positionSetvar=2;
                                                timeStamp= time_ms;
                                                SPI1_Send(Rev);

                                            break;
                                        case 0x02:
                                            //printf("RIGHT");

                                                update = 1;
                                                positionSetvar=3;
                                                timeStamp= time_ms;
                                                SPI1_Send(Off);

                                            break;
                                        default:
                                            printf("Error: Invalid direction code - terminating");
                                            break;
                                    }
                                    break;
                                }
                            subtype = d;
                        }
                }
                    
                    
                    // Determine if message is too long
                    message_last_ii= message_ii;
                    message_ii = message_ii+1;
                    if (message_ii<MSGTESTSIZE){} else{
                        //printf(" message too large. deleting ");
                        message_incoming=0;
                        message_ii=0;
                    }
                }
                buffer_last_ii= buffer_ii;
                buffer_ii = (buffer_ii+1)%BUFSIZE;

                //printf("%s,%s\r\n",buffer_in,message_in);
                //__delay_ms(1);
                
        }
        
    }
}

